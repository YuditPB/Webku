@extends('wisatas.layout')

@section('content')

<form action="{{route('wisatas.update', $wisata->id)}}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" value="{{$wisata->nama}}"><br><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" value="{{$wisata->kota}}"><br><br>
    <label for="">Harga Tiket</label><br>
    <input type="number" name="harga_tiket" id="" value="{{$wisata->harga_tiket}}"><br><br>
    <label for="">Image</label><br>
    <input type="file" name="image" id="" value="{{$wisata->image}}"><br><br>
    <input class="btn btn-primary" type="submit" value="Simpan">
</form>

@endsection