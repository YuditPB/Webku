@extends('wisatas.layout')

@section('content')
    <a href="{{route('wisatas.create')}}"><button class="btn btn-primary">Tambah</button></a>
    <br><br>
    <table class="table table-bordered">
        <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Kota</th>
            <th>Harga Tiket</th>
            <th>Gambar</th>
            <th>Aksi</th>
        </tr>
        </thead>

        @foreach ($wisatas as $wi)
            <tr>
                <td>{{$wi->id}}</td>
                <td>{{$wi->nama}}</td>
                <td>{{$wi->kota}}</td>
                <td>{{$wi->harga_tiket}}</td>
                <td><img src="{{Storage::url('public/images/'.$wi->image)}}" alt="" style="width: 150px"></td>
                <td>
                    <a href="{{route('wisatas.show', $wi->id)}}"><button class="btn btn-success">Show</button></a>
                    <a href="{{route('wisatas.edit', $wi->id)}}"><button class="btn btn-warning">Edit</button></a>
                    <form onclick="return confirm('Are you sure?')" action="{{route('wisatas.destroy', $wi->id)}}" method="post" style="display:inline;">
                        @csrf
                        @method('DELETE')
                            <button class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
    {{$wisatas->links()}}
@endsection