@extends('wisatas.layout')

@section('content')
    <h2>{{$wisata->id}}</h2>
    <br>
    <p>Nama: {{$wisata->nama}}</p>
    <p>Kota: {{$wisata->kota}}</p>
    <p>Harga Tiket: {{$wisata->harga_tiket}}</p>
    <p>Image: <br><img src="{{Storage::url('public/images/'.$wisata->image)}}" alt="" style="width: 2048"></p>
@endsection