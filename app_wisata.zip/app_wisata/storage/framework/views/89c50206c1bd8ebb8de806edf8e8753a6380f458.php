<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('wisatas.create')); ?>"><button class="btn btn-primary">Tambah</button></a>
    <br><br>
    <table class="table table-bordered">
        <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Kota</th>
            <th>Harga Tiket</th>
            <th>Gambar</th>
            <th>Aksi</th>
        </tr>
        </thead>

        <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($wi->id); ?></td>
                <td><?php echo e($wi->nama); ?></td>
                <td><?php echo e($wi->kota); ?></td>
                <td><?php echo e($wi->harga_tiket); ?></td>
                <td><img src="<?php echo e(Storage::url('public/images/'.$wi->image)); ?>" alt="" style="width: 150px"></td>
                <td>
                    <a href="<?php echo e(route('wisatas.show', $wi->id)); ?>"><button class="btn btn-success">Show</button></a>
                    <a href="<?php echo e(route('wisatas.edit', $wi->id)); ?>"><button class="btn btn-warning">Edit</button></a>
                    <form onclick="return confirm('Are you sure?')" action="<?php echo e(route('wisatas.destroy', $wi->id)); ?>" method="post" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($wisatas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/index.blade.php ENDPATH**/ ?>