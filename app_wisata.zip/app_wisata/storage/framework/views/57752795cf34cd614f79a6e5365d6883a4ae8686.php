<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('wisatas.update', $wisata->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" value="<?php echo e($wisata->nama); ?>"><br><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" value="<?php echo e($wisata->kota); ?>"><br><br>
    <label for="">Harga Tiket</label><br>
    <input type="number" name="harga_tiket" id="" value="<?php echo e($wisata->harga_tiket); ?>"><br><br>
    <label for="">Image</label><br>
    <input type="file" name="image" id="" value="<?php echo e($wisata->image); ?>"><br><br>
    <input class="btn btn-primary" type="submit" value="Simpan">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>