<?php $__env->startSection('content'); ?>
    <h2><?php echo e($wisata->id); ?></h2>
    <br>
    <p>Nama: <?php echo e($wisata->nama); ?></p>
    <p>Kota: <?php echo e($wisata->kota); ?></p>
    <p>Harga Tiket: <?php echo e($wisata->harga_tiket); ?></p>
    <p>Image: <br><img src="<?php echo e(Storage::url('public/images/'.$wisata->image)); ?>" alt="" style="width: 2048"></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>